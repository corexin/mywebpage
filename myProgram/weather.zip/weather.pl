#
#	Author	: Chao Jiang
#	Date  	: 09/09/2006	
#
use LWP::Simple;

open(OUT,">data.txt") || die "can not open output file";

#hash table to hold location and related code
 %locationCode=("MELBOURNE"=>'IDCJDW3051',"MILDURA"=>'IDCJDW3050',"SYDNEY"=>'IDCJDW2124');
 
 #input a location
print "Location Options\n";
foreach (keys %locationCode){
	print  $_."\n";
}
print "Key in your option please:\n";
my $loc_in="";
while(!(exists $locationCode{uc($loc_in)})){
	$loc_in=<STDIN>;
	chomp($loc_in);
}
chomp($loc_in);
$loc_in = uc($loc_in);

#input year and month
my $date_in;
print "Date Options input format(#ccyymm)\n";
print "Key in the date please:\n";
while($date_in!~/^[12]\d{3}[0-1][1-9]/){
	$date_in=<STDIN>;
	chomp($date_in);
	
}
print "You have choose Location:\t".$locationCode{$loc_in}."\n";
print "You have choose Date:\t\t".$date_in."\n";

#location of data coming from
 $url="http:\/\/www\.bom\.gov\.au\/climate\/dwo\/$date_in\/html\/$locationCode{$loc_in}\.$date_in\.shtml";
 print "Retrieving Information from $url\n";

 my $content = get($url);

 my $allinfo;
 if($content=~/(\<table.*\<\/table\>)\<.*START OF STANDARD BUREAU FOOTER/i){
 	$allinfo=$1;
 }

#split table into array
my @tmp=split(/<\/tr>/,$allinfo); 
print "Day\tMinTemp\tMaxTemp\tRain\tSun\n";

#for each array take out related values and put into a file and print on screen
foreach (@tmp){
	if($_=~/<tr><th.*?>(.*?)<\/th><td.*?>.*?<\/td><td.*?>(.*?)<\/td><td.*?>(.*?)<\/td><td.*?>(.*?)<\/td><td.*?>.*?<\/td><td.*?>(.*?)<\/td>/){
	print "$1\t$2\t$3\t$4\t$5\n";
	print OUT "$1\t$2\t$3\t$4\t$5\n";
	}

}
close(OUT);

#end

